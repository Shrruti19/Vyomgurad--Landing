function Hero() {
  return (
    <section className="p-8 text-center">
      <h2 className="text-4xl font-bold mb-4">Welcome to Vyomgarud Landing Page</h2>
      <p className="text-lg">This is a simple landing page for your assignment submission.</p>
    </section>
  )
}

export default Hero
